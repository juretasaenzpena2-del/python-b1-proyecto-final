from dataclasses import dataclass, field
from typing import List

from users import Cashier, Customer
from products import Product


@dataclass
class Order:
    cashier: Cashier
    customer: Customer
    products: List[Product] = field(default_factory=list)

    def add(self, product: Product) -> None:
        self.products.append(product)

    def calculateTotal(self) -> float:
        total = 0.0
        for p in self.products:
            total += float(p.price)
        return total

    def show(self) -> None:
        print("\n=== ORDER ===")
        print(self.cashier.describe())
        print(self.customer.describe())

        print("\nProducts:")
        if not self.products:
            print("  (sin productos)")
        else:
            for p in self.products:
                print("  - " + p.describe())

        print(f"\nTOTAL: €{self.calculateTotal():.2f}")
        print("=============\n")
