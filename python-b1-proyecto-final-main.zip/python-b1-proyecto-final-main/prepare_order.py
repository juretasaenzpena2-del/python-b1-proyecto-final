# prepare_order.py
from typing import Dict, List, Optional

from users import Cashier, Customer
from products import Product, Hamburger, Soda, Drink, HappyMeal
from util import CSVFileManager, CashierConverter, CustomerConverter, ProductConverter
from orders import Order


class PrepareOrder:
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir

        self.cashiers: List[Cashier] = []
        self.customers: List[Customer] = []
        self.products: List[Product] = []
        self.products_by_id: Dict[str, Product] = {}

        # Cargar todo al iniciar
        self.load_data()

    def load_data(self) -> None:
        # --- Leer CSV ---
        cashiers_path = f"{self.data_dir}/cashiers.csv"
        customers_path = f"{self.data_dir}/customers.csv"
        hamburgers_path = f"{self.data_dir}/hamburgers.csv"
        sodas_path = f"{self.data_dir}/sodas.csv"
        drinks_path = f"{self.data_dir}/drinks.csv"
        happy_path = f"{self.data_dir}/happyMeal.csv"

        cashiers_df = CSVFileManager(cashiers_path).read()
        customers_df = CSVFileManager(customers_path).read()
        hamburgers_df = CSVFileManager(hamburgers_path).read()
        sodas_df = CSVFileManager(sodas_path).read()
        drinks_df = CSVFileManager(drinks_path).read()
        happy_df = CSVFileManager(happy_path).read()

        # --- Convertir a objetos ---
        self.cashiers = CashierConverter().convert(cashiers_df)
        self.customers = CustomerConverter().convert(customers_df)

        pc = ProductConverter()
        hamburgers = pc.convert(hamburgers_df, Hamburger)
        sodas = pc.convert(sodas_df, Soda)
        drinks = pc.convert(drinks_df, Drink)
        happy_meals = pc.convert(happy_df, HappyMeal)

        self.products = hamburgers + sodas + drinks + happy_meals
        self.products_by_id = {p.id: p for p in self.products}

    def find_cashier(self, dni: str) -> Optional[Cashier]:
        dni = dni.strip()
        for c in self.cashiers:
            if c.dni == dni:
                return c
        return None

    def find_customer(self, dni: str) -> Optional[Customer]:
        dni = dni.strip()
        for c in self.customers:
            if c.dni == dni:
                return c
        return None

    def list_cashiers(self) -> None:
        print("\n=== CAJEROS ===")
        if not self.cashiers:
            print("(No hay cajeros cargados)")
        for c in self.cashiers:
            print(" - " + c.describe())
        print()

    def list_customers(self) -> None:
        print("\n=== CLIENTES ===")
        if not self.customers:
            print("(No hay clientes cargados)")
        for c in self.customers:
            print(" - " + c.describe())
        print()

    def list_products(self) -> None:
        print("\n=== PRODUCTOS DISPONIBLES ===")
        if not self.products:
            print("(No hay productos cargados)")
        for p in self.products:
            print(" - " + p.describe())
        print("============================\n")

    def create_order_flow(self) -> None:
        cashier_dni = input("DNI del cajero: ").strip()
        cashier = self.find_cashier(cashier_dni)
        if not cashier:
            print("No se encontró cajero con ese DNI.\n")
            return

        customer_dni = input("DNI del cliente: ").strip()
        customer = self.find_customer(customer_dni)
        if not customer:
            print("No se encontró cliente con ese DNI.\n")
            return

        order = Order(cashier=cashier, customer=customer)

        self.list_products()
        print("Ingresá IDs de producto para agregar. ENTER para terminar.\n")

        while True:
            pid = input("ID producto: ").strip()
            if pid == "":
                break

            p = self.products_by_id.get(pid)
            if not p:
                print("ID no encontrado. Probá de nuevo.")
                continue

            order.add(p)
            print(f"Agregado: {p.name} (€{p.price:.2f})")

        order.show()

    def run_menu(self) -> None:
        while True:
            print("1) Listar cajeros")
            print("2) Listar clientes")
            print("3) Listar productos")
            print("4) Crear orden")
            print("0) Salir")

            opt = input("Opción: ").strip()

            if opt == "1":
                self.list_cashiers()
            elif opt == "2":
                self.list_customers()
            elif opt == "3":
                self.list_products()
            elif opt == "4":
                self.create_order_flow()
            elif opt == "0":
                print("Saliendo...")
                break
            else:
                print("Opción inválida.\n")


if __name__ == "__main__":
    PrepareOrder(data_dir="data").run_menu()
