from __future__ import annotations
from abc import ABC, abstractmethod
class FoodPackage (ABC): 
    @abstractmethod
    def pack(self)  -> str:
        raise NotImplementedError
    
    @abstractmethod
    def material(self) -> str:
        raise NotImplementedError
    
    def describe(self):
        return f"Empaque: {self.pack()} , Material: {self.material()}"    
    
class Wrapping(FoodPackage):  
  def pack(self) -> str:
     return "Food Wrap Paper"
  def material(self) -> str:
     return "Aluminium"

class Bottle(FoodPackage):  
  def pack(self)-> str:
    return "Bottle"
  def material (self)-> str:
    return "Plastic"
      
class Glass(FoodPackage):  
  def pack(self)-> str:
    return "Glass"
  def material (self)-> str:
    return "Carboard"

class Box(FoodPackage):  
  def pack(self)-> str:
    return "Box"
  def material (self) -> str:
    return "Carboard"