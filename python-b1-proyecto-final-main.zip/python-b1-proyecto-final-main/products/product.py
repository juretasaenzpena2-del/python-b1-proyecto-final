from abc import ABC, abstractmethod
from dataclasses import dataclass

from products.food_package import FoodPackage, Wrapping, Bottle, Glass, Box


@dataclass
class Product(ABC):
    id: str
    name: str
    price: float

    @abstractmethod
    def type(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def foodPackage(self) -> FoodPackage:
        raise NotImplementedError

    # ✅ ESTE MÉTODO ES EL QUE FALTABA
    def describe(self) -> str:
        pkg = self.foodPackage()
        return (
            f"[{self.id}] {self.name} | €{self.price:.2f} | "
            f"Type: {self.type()} | "
            f"Package: {pkg.pack()} ({pkg.material()})"
        )


class Hamburger(Product):
    def type(self) -> str:
        return "Hamburger"

    def foodPackage(self) -> FoodPackage:
        return Wrapping()


class Soda(Product):
    def type(self) -> str:
        return "Soda"

    def foodPackage(self) -> FoodPackage:
        return Glass()


class Drink(Product):
    def type(self) -> str:
        return "Drink"

    def foodPackage(self) -> FoodPackage:
        return Bottle()


class HappyMeal(Product):
    def type(self) -> str:
        return "HappyMeal"

    def foodPackage(self) -> FoodPackage:
        return Box()
