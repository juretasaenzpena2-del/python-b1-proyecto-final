from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass

@dataclass
class User(ABC):
    dni: str
    name: str
    age: int

    @abstractmethod
    def describe(self) -> str:
        raise NotImplementedError
    
@dataclass
class Cashier(User):
    # campos extra típicos (opcionales)
    employee_id: str = ""
    shift: str = ""

    def describe(self) -> str:
        extra = []
        if self.employee_id:
            extra.append(f"employee_id={self.employee_id}")
        if self.shift:
            extra.append(f"shift={self.shift}")
        extra_txt = (" | " + ", ".join(extra)) if extra else ""
        return f"Cashier: {self.name} (DNI: {self.dni}, Age: {self.age}){extra_txt}"
    
@dataclass
class Customer (User):
    #campos posibles opcionales
    email: str = ""
    phone: str = ""

    def describe(self) -> str:
        extra = []
        if self.email:
            extra.append(f"email={self.email}")
        if self.phone:
            extra.append(f"phone={self.phone}")
        extra_txt = (" | " + ", ".join(extra)) if extra else ""
        return f"Customer: {self.name} (DNI: {self.dni}, Age: {self.age}){extra_txt}"
      

