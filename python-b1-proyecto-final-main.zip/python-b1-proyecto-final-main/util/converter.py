# util/converter.py
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, List, Type

import pandas as pd

from users import Cashier, Customer
from products import Hamburger, Soda, Drink, HappyMeal, Product


class Converter(ABC):
    @abstractmethod
    def convert(self, dataFrame: pd.DataFrame, *args) -> list:
        """Convierte un DataFrame en una lista de objetos."""
        raise NotImplementedError

    def print(self, list_objects: list) -> None:
        """Imprime la info de los objetos."""
        for obj in list_objects:
            if hasattr(obj, "describe"):
                print(obj.describe())
            else:
                print(obj)


class CashierConverter(Converter):
    def convert(self, dataFrame: pd.DataFrame, *args) -> List[Cashier]:
        if dataFrame is None:
            raise ValueError(
                "CashierConverter recibió dataFrame=None. "
                "Revisá CSVFileManager.read() (debe devolver un DataFrame) y la ruta del CSV."
            )

        res: List[Cashier] = []
        for _, row in dataFrame.iterrows():
            d = row.to_dict()

            dni = str(d.get("dni", d.get("DNI", ""))).strip()
            name = str(d.get("name", d.get("Name", ""))).strip()
            age = int(d.get("age", d.get("Age", 0)) or 0)

            # Campos extra opcionales (si existen en el CSV)
            employee_id = str(d.get("employee_id", d.get("employeeId", "")) or "").strip()
            shift = str(d.get("shift", "") or "").strip()

            res.append(
                Cashier(
                    dni=dni,
                    name=name,
                    age=age,
                    employee_id=employee_id,
                    shift=shift,
                )
            )
        return res


class CustomerConverter(Converter):
    def convert(self, dataFrame: pd.DataFrame, *args) -> List[Customer]:
        if dataFrame is None:
            raise ValueError(
                "CustomerConverter recibió dataFrame=None. "
                "Revisá CSVFileManager.read() (debe devolver un DataFrame) y la ruta del CSV."
            )

        res: List[Customer] = []
        for _, row in dataFrame.iterrows():
            d = row.to_dict()

            dni = str(d.get("dni", d.get("DNI", ""))).strip()
            name = str(d.get("name", d.get("Name", ""))).strip()
            age = int(d.get("age", d.get("Age", 0)) or 0)

            # Campos extra opcionales (si existen en el CSV)
            email = str(d.get("email", "") or "").strip()
            phone = str(d.get("phone", "") or "").strip()

            res.append(
                Customer(
                    dni=dni,
                    name=name,
                    age=age,
                    email=email,
                    phone=phone,
                )
            )
        return res


class ProductConverter(Converter):
    """
    Convierte un DF a una lista del tipo Product que se indique por parámetro.
    Uso:
        ProductConverter().convert(df, Hamburger)  -> list[Hamburger]
    """

    def convert(self, dataFrame: pd.DataFrame, *args) -> List[Product]:
        if dataFrame is None:
            raise ValueError(
                "ProductConverter recibió dataFrame=None. "
                "Revisá CSVFileManager.read() (debe devolver un DataFrame) y la ruta del CSV."
            )

        if not args:
            raise ValueError(
                "ProductConverter requiere el tipo de producto, ej: convert(df, Hamburger)"
            )

        product_cls: Type[Product] = args[0]

        res: List[Product] = []
        for _, row in dataFrame.iterrows():
            d: dict[str, Any] = row.to_dict()

            # Intentamos cubrir headers comunes
            pid = str(d.get("id", d.get("product_id", d.get("barcode", "")))).strip()
            name = str(d.get("name", d.get("product_name", d.get("Name", "")))).strip()
            price = float(d.get("price", d.get("Price", 0)) or 0)

            res.append(product_cls(id=pid, name=name, price=price))
        return res
