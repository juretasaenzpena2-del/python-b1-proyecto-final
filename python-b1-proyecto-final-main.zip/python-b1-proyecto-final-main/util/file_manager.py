import os
import pandas as pd


class CSVFileManager:
    def __init__(self, path: str):
        self.path = path

    def read(self) -> pd.DataFrame:
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"No existe el archivo: {self.path}")

        df = pd.read_csv(self.path)
        return df  # <-- CLAVE: devolver el DataFrame

    def write(self, dataFrame: pd.DataFrame) -> None:
        dataFrame.to_csv(self.path, index=False)
